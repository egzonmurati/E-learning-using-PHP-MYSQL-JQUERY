<?php
/**
 * Course: Web Backend with PHP
 * Topic: Control Flow
 */
$age = 16;

// 1. Switch/Case/Default
switch ($age) {
    case 10:
    case 11:
    case 15:
        echo 'Vogëlush!' . PHP_EOL;
        break;
    case $age > 15 && $age < 20:
        echo 'Adoleshent!' . PHP_EOL;
        break;
    case $age > 20 && $age < 50:
        echo 'Mosherritur!' . PHP_EOL;
        break;
    case $age > 50:
        echo 'Kadal-dal oh po vjeno pleqnia!' . PHP_EOL;
        break;
    default:
        echo 'Bebush!' . PHP_EOL;
        break;
}

// 2. If/ElseIf/Else
$age = 20;
// example compare with IF equivalent to switch above
if ($age > 15 $age <= 20) {
    echo 'Adoleshent!' . PHP_EOL;
} elseif ($age > 20) {
    echo 'Mosherritur!' . PHP_EOL;
} elseif ($age >= 50) {
    echo 'Kadal-dal oh po vjeno pleqnia!' . PHP_EOL;
} else {
    echo 'Bebush!' . PHP_EOL;
}


$cond_one = false;
$cond_two = true;

if ($cond_one) {
  echo 'Brenda kushtit të parë!' . PHP_EOL;
} elseif ($cond_two) {
  echo 'Jemi brenda t\'dytës!' . PHP_EOL;
} else {
  echo 'Default' . PHP_EOL;
}


// 3. Ternary Operator
$result = isset($name) ? true : false;
// Equivalent to
// if (isset($name)) {
//   $result = true;
// } else {
//   $result = false;
// }

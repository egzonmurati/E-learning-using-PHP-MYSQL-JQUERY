<?php
/**
 * Course: Web Backend with PHP
 * Topic: Arrays
 */

// 1. Associative Arrays
// Long Syntax: $arr = array();
// Short Syntax: $arr = []; for PHP >= 5.4
$name = 'Skypetarë';
$age = 20;
$array = [$name, $age, 'Jon', 11.1];
echo gettype($array) . ': ' . count($array) . PHP_EOL;


// 2. Associative
$country = ['city' => 'Prishtina', 'state' => 'Kosova'];


// 3. Two-dimensional Arrays
$members = [
    [
        'name' => 'Arber',
        'age'  => 21,
    ],
    [
        'name' => 'Valbona',
        'age' => 22,
    ]
];
var_dump($members);


// explode()
$text = 'There are two apples and an orange.';
// echo ucwords($text) . '<br>';
$words = explode(' ', $text);

$newText = '';
foreach ($words as $word) {
    $newText .= ' ' . ucfirst($word);
}
echo $newText . '<br>';

// implode()
$names = ['Shqipetare', 'Berat', 'Ismet', 'Valbone'];
array_push($names, 'Ardian');
array_pop($names);
echo 'Studentet qe jane prezent ne klase: ' . implode(', ', $names) . '!';

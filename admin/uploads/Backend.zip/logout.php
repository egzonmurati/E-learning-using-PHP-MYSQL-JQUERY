<?php

session_start();

$_SESSION['isLoggedIn'] = null;
$_SESSION['isAdmin'] = null;

session_destroy();

header('Location: login.php');

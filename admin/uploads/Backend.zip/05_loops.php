<?php
/**
 * Course: Web Backend with PHP
 * Topic: Loops
 */

$names = ['Albina', 'Alketa', 'Arbnor', 'Arta', 'Artan'];

// 1. Foreach
echo '<strong>' . nl2br("\n-- ForEach Loop --\n") . '</strong>';
foreach ($names as $key => $value) {
    echo nl2br("Index: {$key}: Tung " . $value . "!\n");
}


// 2. For Loop
echo '<strong>' . nl2br("\n-- For Loop --\n") . '</strong>';
for ($i=0; $i < count($names); $i++) {
    if ($i == 3) {
        echo "Hi five veç {$names[$i]} me For Loop! <br>";
    }
}


// 3. While Loop
echo '<strong>' . nl2br("\n-- While Loop --\n") . '</strong>';
$i = 0;
while ($i < count($names)) {
    echo "Hi five {$names[$i]} me While Loop<br>\n";
    $i++;
}


// 4. Do-While Loop
echo '<strong>' . nl2br("\n-- Do-While Loop --\n") . '</strong>';
$i = 0;
do {
    echo nl2br("Hi five veç ${names[$i]} me DoWhile Loop\n");
    $i++;
} while ($i > count($names));

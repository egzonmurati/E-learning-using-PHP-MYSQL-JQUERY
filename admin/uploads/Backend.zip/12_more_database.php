<?php

require_once('database.php');

$errors = [];

if (isset($_POST['submit'])) {
    // $name = $_POST['name'];
    // $email = $_POST['email'];
    // $birthday = $_POST['birthdate'];
    list($name, $email, $birthday) = array_values($_POST);

    if (empty($name) || empty($email) || empty($birthday)) {
        $errors[] = 'All fields are required.';
    }

    if (!ctype_alpha($name)) {
        $errors[] = 'Name must not have numeric characters.';
    }

    if (filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL) === false) {
        $errors[] = 'Invalid email.';
    }

    $sql = "INSERT INTO `students` (name, email, birthday, registered_at) VALUES (?, ?, ?, ?)";
    $stmt = $mysql->prepare($sql);
    $today = date('y-m-d H:s:i', time());
    $stmt->bind_param('ssss', $name, $email, $birthday, $today);

    if (!$stmt->execute()) {
        var_dump($stmt->error_list); die();
    }
}

if (!empty($errors)) :
    echo '<ul>';
    foreach ($errors as $error) {
        echo '<li>' . $error . '</li>';
    }
    echo '<ul>';
endif;

$errors = [];

?>

<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
    <p>
        <label for="name">Your Name</label><br>
        <input type="text" name="name" id="name">
    </p>
    <p>
        <label for="email">Your Email</label><br>
        <input type="text" name="email" id="email">
    </p>
    <p>
        <label for="birthdate">Your Birthdate</label>
        <input type="date" name="birthdate" id="birthdate">
    </p>
    <p>
        <input type="submit" name="submit" value="Send">
    </p>
</form>

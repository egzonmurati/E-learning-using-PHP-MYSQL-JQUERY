<?php
require_once('shared/header.php');

if (isset($_GET['slug'])) {
    $slug = $_GET['slug'];
    $stmt = $mysql->prepare("SELECT * FROM songs WHERE slug = ?");
    $stmt->bind_param('s', $slug);
    $stmt->execute();

    if ($stmt) {
        $song = $stmt->get_result()->fetch_object();
    }
}
?>

<div class="col-md-8 blog-main">
    <h3 class="pb-4 mb-4 font-italic border-bottom">
        <?= $song->title ?? '' ?>
    </h3>
    <div class="blog-post">
        <h2 class="blog-post-title"><?= $song->title ?></h2>
        <p><?= $song->lyric ?></p>
        <p class="blog-post-meta">Published at: <?= $song->created_at ?><br>
            Thanks: <a href="#"><?= $song->submitted_by ?></a></p>
    </div>
</div>

<?php  require_once('shared/footer.php');
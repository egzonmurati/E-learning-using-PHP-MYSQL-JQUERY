<?php
require_once('shared/header.php');

if (isset($_POST['submit'])) {
    list($title, $lyric, $artistId) = array_values($_POST);

    $sql = "INSERT INTO `songs` (title, lyric, slug, artist_id, submitted_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $today = date('y-m-d H:s:i', time());
    $slug = strtolower(str_replace(' ', '-', $title));
    $stmt = $mysql->prepare($sql);

    $values = [$title, $lyric, $slug, $artistId, 'dummyemail@me.com', $today, $today];
    $stmt->bind_param('sssssss', ...$values);
    $success = $stmt->execute();

    if ($success) {
        $_SESSION['flash'] = 'Song inserted succesfully.';
    }
}


$result = $mysql->query('SELECT id, name FROM artists');

if (!$result) $artist = [];

$artists = $result->fetch_all(MYSQLI_ASSOC);


if (isset($_SESSION['flash'])) {
    echo '<div class="alert alert-success>' . $_SESSION['flash'] . '</div>';
    unset($_SESSION['flash']);
}
?>

<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
    <div class="form-group">
        <label for="songTitle">Song Title</label>
        <input type="text" name="title" id="songTitle" class="form-control">
    </div>
    <div class="form-group">
        <label for="songText"></label>
        <textarea name="lyric" id="songText"rows="5" class="form-control"></textarea>
    </div>
    <div class="form-group">
        <label for="artist"></label>
        <select name="artist" id="artist" class="form-control">
            <?php foreach ($artists as $key => $artist) {
                echo '<option value="' . $artist['id'] .'">' . $artist['name'] . '</option>';
            } ?>
        </select>
    </div>

    <button type="submit" name="submit" class="btn btn-primary">Save</button>
</form>

<?php require_once 'shared/footer.php';
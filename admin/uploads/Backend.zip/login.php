<?php
require_once('shared/header.php');

if (isset($_SESSION['isLoggedIn'])) header("Location: index.php");

$errors = [];
if (isset($_POST['submit'])) {
    list($email, $password) = array_values($_POST);

    $email = $mysql->real_escape_string($email);
    $result = $mysql->query("SELECT * FROM users WHERE email = '{$email}'");

    if (!$result) {
        $errors[] = 'User not found.';
    }

    $user = $result->fetch_assoc();

    if (!password_verify($password, $user['password'])) {
        $errors[] = 'Invalid credentials.';
    }

    if (empty($errors)) {
        $_SESSION['isLoggedIn'] = true;
        $_SESSION['isAdmin'] = $user['isAdmin'] ? true : false;
        header("Location: index.php");
    } else {
        // TODO: pritn error message
        var_dump($errors);
    }
}

?>

<form class="form-signin" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
    <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
    <label for="inputEmail" class="sr-only">Email address</label>
    <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
    <label for="inputPassword" class="sr-only">Password</label>
    <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
    <!-- <div class="checkbox mb-3">
        <label>
            <input type="checkbox" value="remember-me"> Remember me
        </label>
    </div> -->
    <button class="btn btn-lg btn-primary btn-block" name="submit" type="submit">Sign in</button>
</form>

<?php require_once('shared/footer.php');
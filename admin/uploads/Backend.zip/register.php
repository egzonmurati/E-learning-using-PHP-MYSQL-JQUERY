<?php
require_once('shared/header.php');

$errors = [];

if (isset($_POST['submit'])) {
    list($name, $email, $password, $confirmPassword) = array_values($_POST);

    if (filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL) === false) {
        $errors[] = 'Invalid email.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO `users` (name, email, password, registered_at) VALUES (?, ?, ?, ?)";
    $stmt = $mysql->prepare($sql);
    $today = date('y-m-d H:s:i', time());
    $stmt->bind_param('ssss', $name, $email, $hashedPassword, $today);

    if (!empty($errors) || !$stmt->execute()) {
        var_dump($errors, $stmt->error_list); die();
    } else {
        header('Location: login.php');
    }

    // TODO: pritn error message
}

?>
<form class="form-signin" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
    <h1 class="h3 mb-3 font-weight-normal">Sign Up</h1>
    <div class="form-group">
        <label for="inputName" class="sr-only">Full name</label>
        <input type="text" name="name" id="inputName" class="form-control" placeholder="Your name" required autofocus>
    </div>
    <div class="form-group">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
    </div>
    <div class="form-group">
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
    </div>
    <div class="form-group">
        <label for="inputConfirmPassword" class="sr-only">Confirm Password</label>
        <input type="password" name="confirmPassword" id="inputConfirmPassword" class="form-control" placeholder="Confirm Password" required>
    </div>
    <div class="form-group">
        <button class="btn btn-lg btn-primary btn-block" name="submit" type="submit">Register</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2017-2019</p>
    </div>
</form>

<?php require_once('shared/footer.php');
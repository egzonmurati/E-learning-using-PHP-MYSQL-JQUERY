<?php
/**
 * Course: Web Backend with PHP
 * Topic: Variables and Primitive Data Types (String, Integer, Float, Boolean)
 */

// 1. Strings
$academy = "Akademia Xhezairi";
$courseTitle  = 'Web Backend with PHP';
$char  = chr(65); // char A
echo $academy . PHP_EOL;
var_dump($courseTitle);


// 2. Integers
$age = 20;
// Type hinting
$age = (int) '20';
echo gettype($age) . PHP_EOL;


// 3. Floats (Doubles)
// Returned as Double w/ gettype()
$price = 12.5;
var_dump($price);
echo $price . PHP_EOL;


// 4. Booleans
$trueOrFalse = true;
$boolean = 12 > 15;
var_dump([$trueOrFalse, $boolean]);


// 5. CONSTANTs
define('PI', 3.14);
const PIC = 3.14;
var_dump([PI, PIC]);
echo PIC . "\n";

<?php

require_once('shared/header.php');

if (isset($_GET['slug'])) {
    $slug = $_GET['slug'];
    $stmt = $mysql->prepare("SELECT id, name FROM artists WHERE slug = ?");
    $stmt->bind_param('s', $slug);
    $stmt->execute();

    if ($stmt) {
        $result = $stmt->get_result();
        $artist = $result->fetch_assoc();

        $sql = "SELECT * FROM songs WHERE artist_id = {$artist['id']}";
        $stmt = $mysql->prepare($sql);
        $stmt->execute();
        $songs = $stmt->get_result();
    }
}
?>

<div class="col-md-8 blog-main">
        <h3 class="pb-4 mb-4 font-italic border-bottom">
        <?= !empty($songs) ? 'Listing songs for artist ' . $artist['name'] : '' ?>
        </h3>
    <div class="blog-post">
        <?php foreach ($songs as $song) : ?>
            <ul class="list-group list-group-flush">
                <li class="list-group-item list-group-item-action">
                    <a href="song.php?slug=<?= $song['slug'] ?>"><?= $song['title'] ?></a></li>
            </ul>
        <?php endforeach; ?>
    </div>
</div>


<?php require_once('shared/footer.php');
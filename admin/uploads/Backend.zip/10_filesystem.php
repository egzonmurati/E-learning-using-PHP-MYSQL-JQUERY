<?php
/**
 * Course: Web Backend with PHP
 * Topic: Filesystem
 */

// Procedural
$fileName = 'data/people.txt';
$fileInfo = pathinfo($filename);

if (is_readable($filename)) {
    die('You are trying to read a directory.');
}


// Reading whole file into an array of lines
$content = file($filename); // file_get_contents($filename);
foreach ($content as $key => $line) {
    echo $line . '<br>';
}


// Reading whole file into a string
$fh = fopen($filename, 'r') or die('Cannot read file.');
$content = fread($fh, filesize($filename));
foreach (explode(PHP_EOL, $content) as $key => $line) {
    echo $line . '<br>';
}


// Writing
$filename = 'data/names.txt';
$fh = fopen($filename, 'a+'); // create if not exist and append to EOF
fwrite($fh, 'This is a random line.' . PHP_EOL);


// Closing
fclose($fh);


// OOP File IO
// __FILE__ - points to self
try {
    $file = new SplFileObject($fileName);

    foreach ($file as $line_num => $line) {
        if (empty($line)) return;

        echo "L{$line_num}: ${line}<br>";
    }
} catch(RuntimeException $exception) {
    echo $exception->getLine(); exit;
}

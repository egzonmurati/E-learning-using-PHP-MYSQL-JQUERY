<?php
/**
 * Course: Web Backend with PHP
 * Topic: Types of Operators
 */

// Assignment Operator
// =
$a = 10;
$b = 5;


// Arithmetic Operation
// +  -  *  /  % **
$sum = $a + $b; # 15
$sum = $a - $b; # 5
$sum = $a * $b; # 50
$sum = $a / $b; # 2
$sum = $a % $b; # 0


// Comparison Operators
// <  >  <=  >=  <>  !=  ==  ===
$sum = $a > $b; # true
$sum = $a < $b; # false
$sum = $a <= $b; # false
$sum = $a >= $b; # true
$sum = $a != $b; # true
$sum = $a == $b; # false
$sum = $a === $b; # false
//var_dump($sum);


// Logical Operators
// && (and)  || (or)  xor
$a = (false && moo());
$b = (true  || moo());

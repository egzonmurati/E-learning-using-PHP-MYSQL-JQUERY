<?php
/**
 * Course: Web Backend with PHP
 * Topic: Cookies & Sessions
 */

// Cookies - Stored on client-side
$counter = isset($_COOKIE['counter']) ? $_COOKIE['counter'] += 5 : 1;
setcookie('counter', $counter, strtotime('+1 Week'));


// Sessions - Stored on serve-side
session_start();
$startedAt = $_SESSION['started_at'] ?? ($_SESSION['started_at'] = time());
$views = $_SESSION['views'] = isset($_SESSION['views']) ? ++$_SESSION['views'] : 1;


$output = <<<MSG
This session was created on %s, at %s. Your ID is <b>%s</b>.<br>
Current count is %d. This is your visit number %d.<br>
MSG;

printf($output, date('F j, Y', $startedAt), date('H:i:s', $startedAt), session_id(), $counter, $views);

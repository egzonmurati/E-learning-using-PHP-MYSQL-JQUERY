<?php
/**
 * Course: Web Backend with PHP
 * Topic: Functions
 */

function simpleGreet() {
    return 'Hello Stranger!';
}
// echo simpleGreet();


function calculateAge($value) {
    if (! is_int($value)) {
        return exit('Wrong value type.');
    }

    if ($value > 18) {
        return 'You are an adult!';
    } else {
        return 'Go home, you are too young!';
    }
}
// echo calculateAge(23);


// Variable number of arguments prior PHP v5.6
function calculateSum() {
    // func_get_arg(1) - only one element
    // func_num_args()

    // $sum = 0;
    // foreach (func_get_args() as $num) {
    //     $sum += $num;
    // }
    return array_sum(func_get_args());
}
// echo calculateSum(10, 101, 34, 3, 5, 99, 50);


// Variadic Functions - Splat Operator
function welcomeMembers(...$persons) {
    // $names = array_shift($persons);
    if (is_array($persons[0])) {
        $persons = array_shift($persons);
    }

    foreach ($persons as $name) {
        echo 'Hello ' . $name . '<br>';
    }
}
// $names = ['Ismet', 'Genc', 'Taunita', 'Zyber'];
// welcomeMembers(['Ismet', 'Genc', 'Taunita', 'Zyber']);


// Closures
$sayHello = function ($name) {
    echo 'Howdy ' . $name;
};
$sayHello('Adem');

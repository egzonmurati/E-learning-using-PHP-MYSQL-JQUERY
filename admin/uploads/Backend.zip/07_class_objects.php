<?php
/**
 * Course: Web Backend with PHP
 * Topic: Classes & Objects
 */

// CONSTANTS
define('APP_NAME', 'My Awesome App');
define('APP_VERSION', '1.0.1');

class Television {

    const YEAR_OF_PRODUCTION = 2020;

    private $name;

    public $buttons;

    private $muted = false;

    protected $volume = 11;

    /**
     * [$countryOfOrigin description]
     * @var string
     */
    public static $countryOfOrigin = 'Korea';

    /**
     * [__construct description]
     * @param [type]  $name    [description]
     * @param integer $buttons [description]
     */
    public function __construct($name, $buttons = 5) {
        $this->name = $name;
        $this->buttons = $buttons;
    }

    public static function getClassName()
    {
        return __CLASS__;
    }

    /**
     * Get the name of the object instance
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    public function increaseVolume()
    {
        return $this->volume++;
    }

    public function decreaseVolume()
    {
        return $this->volume--;
    }

    public function getCurrentVolume()
    {
        return $this->volume;
    }
}

$myTv = new Television('Samsung', 6);
$myTv2 = new Television('LG');

echo Television::$countryOfOrigin . '<br>';
echo Television::getClassName() . '<br>';

echo $myTv->getName() . '<br>';

echo $myTv->getName() . " has {$myTv->buttons} buttons.<br>";
echo $myTv2->getName() . " has {$myTv2->buttons} buttons.<br>";

echo APP_NAME . '<br>';

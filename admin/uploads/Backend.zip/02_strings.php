<?php
/**
 * Course: Web Backend with PHP
 * Topic: Variables - String Operations (Concatenation and Interpolation)
 */

// Escaped Characters is a random character
// preceded with a backslash within double quoted strings.
// \n  \t  \\  \$


// 1. String Concatenation
$firstName = 'Afrora';
$lastName  = 'Bushi';
$fullName = $firstName . ' ' . $lastName; # similarly "$firstName $lastName";
echo $fullName . PHP_EOL;


// 2. String Interpolation
$fruit  = 'apple';
$message = "I have five ${fruit}s\n";
echo $message;


// 3. Newlines in Browsers
// \n and PHP_EOL is only printed in HTML source code
// use nl2br() to output newlines on Browser
echo nl2br("This is a dummy string to showcase the use of \\n character in browser \n");

echo strrev('Shqipetare');

$line = 'Today is a good day';
echo ucwords($line);

echo strpos($line, 'good');
strlen($line);


// Heredoc equivalent me Double Quotes
// $text = <<<'EOT' # nowdoc
$html = <<<HTML
  <div class='nav-bar'>
    <ul class='nav-list'>
      <li>$someValue</li>
      <li>$whatEver</li>
      <li>$testMe123</li>
    </ul>
  </div>
HTML;
echo $html;

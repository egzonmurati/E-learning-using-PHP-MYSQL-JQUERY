<?php

require_once 'database.php';

$result = mysqli_query($mysql, 'SELECT * FROM students');
$rows = $result->fetch_all(MYSQLI_ASSOC);

foreach ($rows as $key => $row) {
    echo $row['name'] . ': ' . $row['email'] . '<br>';
}

$result->free();
$mysql->close();

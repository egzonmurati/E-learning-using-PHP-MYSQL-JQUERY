<?php
/*
 * Course: Web Backend with PHP
 * Topic: Comment Formats
 */

// 1. Most used Comment Format
// This is a comment to give clarity on the next line.
$var1 = 'Some random text.';


// 2. Extended Comment Format – Multiple Lines
/**
 * This is a comment
 * to give clarity
 * in multiple lines.
 */
$randomText = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.';


// 3. Inline Comment Format
$fullMessage = 'Welcome to the world of Tralala & Trilili'; # Concatenate every word.

<?php

session_start();

$db = [
    'host' => '127.0.0.1',
    'user' => 'root',
    'pass' => 'root',
    'name' => 'azlyrics'
];

$mysql = new mysqli($db['host'], $db['user'], $db['pass'], $db['name']);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

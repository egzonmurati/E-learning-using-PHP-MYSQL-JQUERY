<?php
/**
 *  Superglobals
 *  $_GET, $_POST, $_SERVER, $_COOKIE, $_SESSION
 *  @link https://www.php.net/manual/en/language.variables.superglobals.php
 */

if (isset($_GET['name'])) {
    $greetings = 'Hello ' . $_GET['name'] . '!';
} else {
    $greetings = 'Hello stranger!<br>';
}

echo $greetings;

if (isset($_POST['submit'])) {
    echo 'You\'ve submitted ' . (count($_POST)-1) . ' form fields.';
}

?>

<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
    <p>
        <label for="name">Your Name</label><br>
        <input type="text" name="user_name" id="name" value="<?= $_GET['name'] ?? '' ?>">
    </p>
    <p>
        <label for="email">Your Email</label><br>
        <input type="text" name="user_email" id="email">
    </p>
    <p>
        <textarea name="message" rows="4"></textarea>
    </p>
    <p>
        <input type="submit" name="submit" value="Send">
    </p>
</form>


<?php

// Database Tables
// t_artists: id, name, slug, created_at
// t_songs: id, artis_id, title, lyric, submitted_by (email), created_at, updated_at
// t_users

require_once('shared/header.php');

if (isset($_GET['list'])) {
    $char = "{$_GET['list']}%";
    $sql = 'SELECT a.name, a.slug, COUNT(s.id) num_songs
        FROM artists a LEFT JOIN songs s ON s.artist_id = a.id WHERE name LIKE ?';
    $stmt = $mysql->prepare($sql);
    $stmt->bind_param('s', $char);
    $stmt->execute();
    $result = $stmt->get_result();

    $html = '<ul class="list-group list-group-flush">';
    while ($artist = $result->fetch_assoc()) {
        $html .= '<li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="artist.php?slug=' . $artist['slug'] .'">' . $artist['name'] . '</a>
            <span class="badge badge-primary badge-pill">'. $artist['num_songs'] .'</span>
        </li>';
    }
    $html .= '</ul>';
}
?>
    <div class="col-md-8 blog-main">
        <h3 class="pb-4 mb-4 font-italic border-bottom">
        <?= isset($char) ? 'Viewing results for artis names with ' . $char : '' ?>
        </h3>
        <div class="blog-post">
            <?= isset($html) ? $html : '' ?>
        </div>
    </div>

<?php require_once('shared/footer.php');
